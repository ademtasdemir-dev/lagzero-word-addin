@echo off
chcp 65001 >nul
if /i "%~1"=="/quiet" set "Q=1"
title LAG^|ZERO Tools fuer Word - Installation
echo.
echo  ==================================================
echo    LAG^|ZERO Tools fuer Microsoft Word
echo    TESTED. MEASURED. OPTIMIZED.
echo  ==================================================
echo.

set "SRC=%~dp0lagzero-word-addin.xml"
set "CAT=%LOCALAPPDATA%\LAGZERO\WordKatalog"
set "KEY=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\{212c4ebf-75af-4458-b496-34fd6f3ecf0b}"

if not exist "%SRC%" (
  echo  [!] lagzero-word-addin.xml nicht gefunden.
  echo      Bitte das ZIP zuerst komplett entpacken:
  echo      Rechtsklick auf das ZIP - "Alle extrahieren".
  echo.
  if not defined Q pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq WINWORD.EXE" 2>nul | find /I "WINWORD.EXE" >nul
if not errorlevel 1 (
  echo  [!] Word ist noch offen.
  echo      Bitte alle Word-Fenster speichern und schliessen,
  echo      dann diese Datei nochmal doppelklicken.
  echo.
  if not defined Q pause
  exit /b 1
)

if not exist "%CAT%" mkdir "%CAT%"
copy /Y "%SRC%" "%CAT%\lagzero-word-addin.xml" >nul
if errorlevel 1 (
  echo  [!] Kopieren hat nicht geklappt.
  if not defined Q pause
  exit /b 1
)

rem Word braucht den Ordner als Netzwerkpfad: C:\... wird zu \\localhost\C$\...
set "DRV=%CAT:~0,1%"
set "UNC=\\localhost\%DRV%$%CAT:~2%"
if not exist "%UNC%\lagzero-word-addin.xml" (
  echo  [!] Der Ordner ist als Netzwerkpfad nicht erreichbar:
  echo      %UNC%
  echo      Das passiert auf manchen Firmen-PCs ohne Admin-Rechte.
  echo      Bitte die Anleitung lesen: Abschnitt "Plan B".
  echo.
  if not defined Q pause
  exit /b 1
)

reg add "%KEY%" /v Id /t REG_SZ /d "{212c4ebf-75af-4458-b496-34fd6f3ecf0b}" /f >nul
reg add "%KEY%" /v Url /t REG_SZ /d "%UNC%" /f >nul
reg add "%KEY%" /v Flags /t REG_DWORD /d 1 /f >nul
if errorlevel 1 (
  echo  [!] Eintrag fuer Word hat nicht geklappt.
  if not defined Q pause
  exit /b 1
)

echo  [OK] Vorbereitet. Jetzt noch 1 Minute in Word:
echo.
echo   1. Word oeffnen (leeres Dokument)
echo   2. Start -^> ganz rechts "Add-Ins" -^> "Weitere Add-Ins"
echo   3. Oben "GETEILTER ORDNER" anklicken
echo   4. "LAG|ZERO Tools" anklicken -^> "Hinzufuegen"
echo.
echo  Danach gibt es oben den Reiter "LAG|ZERO".
echo.
if not defined Q pause
