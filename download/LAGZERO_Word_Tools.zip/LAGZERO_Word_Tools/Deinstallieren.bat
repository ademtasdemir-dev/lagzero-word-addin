@echo off
chcp 65001 >nul
if /i "%~1"=="/quiet" set "Q=1"
title LAG^|ZERO Tools fuer Word - Deinstallation
set "CAT=%LOCALAPPDATA%\LAGZERO\WordKatalog"
set "KEY=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\{212c4ebf-75af-4458-b496-34fd6f3ecf0b}"

tasklist /FI "IMAGENAME eq WINWORD.EXE" 2>nul | find /I "WINWORD.EXE" >nul
if not errorlevel 1 (
  echo  [!] Bitte zuerst Word schliessen, dann nochmal starten.
  if not defined Q pause
  exit /b 1
)

reg delete "%KEY%" /f >nul 2>&1
if exist "%CAT%\lagzero-word-addin.xml" del /F "%CAT%\lagzero-word-addin.xml"
rmdir "%CAT%" >nul 2>&1
rmdir "%LOCALAPPDATA%\LAGZERO" >nul 2>&1

echo  [OK] LAG^|ZERO Tools entfernt.
echo  Falls der Reiter noch da ist: Word -^> Start -^> Add-Ins -^>
echo  Weitere Add-Ins -^> Meine Add-Ins -^> LAG^|ZERO Tools -^> Entfernen.
if not defined Q pause
